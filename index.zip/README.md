# Fx Ninja
## Description
###A skill to get get the current US exchange rate for a country.
A skill to get get the current exchange rate for a country. The base currency is currently set to USD. You can say the country name and the skill will get the US exchange rate for it's currency symbol.

## Usage
* Open the Alexa app on your phone.
* Search for Fx Ninja.
* Enable this skill from your Alexa app.

## Sample Utterances
* Alexa, ask Fx Ninja to get rate for Canada
* Get exchange rate for India
* New Zealand

## Source
The source for the exchange rates is fixer.io 
